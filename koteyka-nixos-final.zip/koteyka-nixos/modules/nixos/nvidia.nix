{ ... }:
{
  # The i5-12400F has no integrated GPU. The RTX 3050 is Ampere and supports
  # NVIDIA's open kernel modules; user-space driver components remain proprietary.
  hardware.graphics.enable = true;
  services.xserver.videoDrivers = [ "nvidia" ];
  hardware.nvidia = {
    open = true;
    modesetting.enable = true;
    nvidiaSettings = true;
  };
}
