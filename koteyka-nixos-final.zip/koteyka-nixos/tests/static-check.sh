#!/usr/bin/env bash
set -Eeuo pipefail

root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$root"

for script in install.sh scripts/kot-wallpaper scripts/kot-theme-from-wallpaper scripts/kot-screenshot; do
  bash -n "$script"
  printf 'PASS bash -n: %s\n' "$script"
done

python3 -m json.tool home/kostya/theme.json >/dev/null
printf 'PASS JSON: home/kostya/theme.json\n'

python3 - <<'PY'
from pathlib import Path
required = [
    "flake.nix",
    "install.sh",
    "hosts/desktop/default.nix",
    "hosts/desktop/disko.nix",
    "modules/nixos/base.nix",
    "modules/nixos/niri.nix",
    "modules/nixos/nvidia.nix",
    "home/kostya/default.nix",
    "home/kostya/niri/config.kdl",
    "home/kostya/quickshell/shell.qml",
    "templates/disko.nix.in",
    "docs/AUDIT.md",
    "docs/PUBLISH.md",
    "docs/GEMINI_REVIEW_PROMPT.md",
    ".github/workflows/validate.yml",
]
missing = [name for name in required if not Path(name).is_file()]
if missing:
    raise SystemExit("Missing required files: " + ", ".join(missing))

flake = Path("flake.nix").read_text(encoding="utf-8")
if 'nixos-26.05' not in flake or 'release-26.05' not in flake:
    raise SystemExit("Flake must use matching NixOS and Home Manager 26.05 stable branches")
if 'niri-config-validation' not in flake or 'niri validate' not in flake:
    raise SystemExit("Flake must include a Niri configuration validation check")

for path in (Path("hosts/desktop/disko.nix"), Path("templates/disko.nix.in")):
    contents = path.read_text(encoding="utf-8")
    if 'format = "ext4"' not in contents:
        raise SystemExit(f"{path} must define ext4 root filesystem")
    if 'format = "btrfs"' in contents:
        raise SystemExit(f"{path} unexpectedly defines Btrfs")

installer = Path("install.sh").read_text(encoding="utf-8")
for token in ("nixos-generate-config", "nix flake check --no-build", "--dry-run", "swapon", "blockdev --getro", "ERASE $disk"):
    if token not in installer:
        raise SystemExit(f"Installer safety/preflight token missing: {token}")
if installer.index('prepare_config_and_preflight "$disk_id"') > installer.index('type exactly: ERASE $disk'):
    raise SystemExit("Preflight must occur before destructive confirmation")
if installer.index('type exactly: ERASE $disk') > installer.index('nix run "$work_config#disko" -- --mode destroy,format,mount --flake "$work_config#koteyka"'):
    raise SystemExit("Disko destructive command must occur after confirmation")
if 'original_disk_real' not in installer or 'check_disk_safety "$disk_id"' not in installer:
    raise SystemExit("Installer must re-check the stable target device after confirmation")

qml = Path("home/kostya/quickshell/shell.qml").read_text(encoding="utf-8")
for token in ("Overview", "Appearance", "System", 'saveTheme("light"', 'saveTheme("dark"', "watchChanges: true", "atomicWrites: true"):
    if token not in qml:
        raise SystemExit(f"Quickshell feature is missing: {token}")

# A lightweight delimiter check catches accidental truncation or unbalanced QML blocks.
stack = []
pairs = {")": "(", "]": "[", "}": "{"}
opening = set(pairs.values())
quote = None
escaped = False
line_comment = False
i = 0
while i < len(qml):
    char = qml[i]
    next_char = qml[i + 1] if i + 1 < len(qml) else ""
    if line_comment:
        if char == "\n":
            line_comment = False
        i += 1
        continue
    if quote:
        if escaped:
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == quote:
            quote = None
        i += 1
        continue
    if char == "/" and next_char == "/":
        line_comment = True
        i += 2
        continue
    if char in ("'", '"'):
        quote = char
    elif char in opening:
        stack.append((char, i))
    elif char in pairs:
        if not stack or stack[-1][0] != pairs[char]:
            raise SystemExit(f"Unbalanced QML delimiter {char!r} near offset {i}")
        stack.pop()
    i += 1
if quote:
    raise SystemExit("Unterminated QML string")
if stack:
    raise SystemExit(f"Unclosed QML delimiter(s): {stack[-3:]}")

for path in Path(".").rglob("*"):
    if not path.is_file() or path.suffix == ".png":
        continue
    try:
        contents = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    if any(ch in contents for ch in ("\u200b", "\u200c", "\u200d", "\ufeff")):
        raise SystemExit(f"Unexpected invisible character in {path}")
print("PASS required files, stable branches, ext4 layout, installer ordering and UI markers")
PY

if python3 -c 'from PIL import Image' >/dev/null 2>&1; then
  temporary_home="$(mktemp -d)"
  trap 'rm -rf -- "$temporary_home"' EXIT
  mkdir -p "$temporary_home/.local/state/kot-os"
  printf '{"accent":"#93B7FF","mode":"light"}\n' > "$temporary_home/.local/state/kot-os/theme.json"
  HOME="$temporary_home" scripts/kot-theme-from-wallpaper "$root/assets/wallpapers/default.png" >/dev/null
  HOME="$temporary_home" python3 - <<'PY_THEME'
import json, os, re
from pathlib import Path
path = Path(os.environ["HOME"]) / ".local/state/kot-os/theme.json"
data = json.loads(path.read_text(encoding="utf-8"))
assert data["mode"] == "light", data
assert re.fullmatch(r"#[0-9A-Fa-f]{6}", data["accent"]), data
print("PASS wallpaper theme sampler preserves mode and writes a valid accent")
PY_THEME
  rm -rf -- "$temporary_home"
  trap - EXIT
else
  printf 'SKIP wallpaper sampler smoke test: Pillow is not installed\n'
fi

if command -v shellcheck >/dev/null 2>&1; then
  shellcheck install.sh scripts/kot-wallpaper scripts/kot-theme-from-wallpaper scripts/kot-screenshot
  printf 'PASS shellcheck\n'
else
  printf 'SKIP shellcheck: not installed\n'
fi

if command -v nix >/dev/null 2>&1; then
  nix --extra-experimental-features "nix-command flakes" flake check --no-build
  nix --extra-experimental-features "nix-command flakes" build --no-link --dry-run .#nixosConfigurations.koteyka.config.system.build.toplevel
else
  printf 'SKIP Nix evaluation: Nix is not installed\n'
fi

printf 'Static checks completed. No disk-writing operation was run.\n'
