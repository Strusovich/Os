#!/usr/bin/env bash
set -Eeuo pipefail

# Allow the exact `./install.sh` workflow from the live ISO.
# Re-exec through sudo once, preserving arguments and the current directory.
if [[ "$EUID" -ne 0 ]]; then
  if ! command -v sudo >/dev/null 2>&1; then
    printf 'sudo is required. Run this installer as root.\n' >&2
    exit 1
  fi
  exec sudo -- "$0" "$@"
fi

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET_ROOT="/mnt"
TARGET_CONFIG="$TARGET_ROOT/etc/nixos"
LOG_FILE="/tmp/koteyka-nixos-install.log"
MIN_DISK_BYTES=$((80 * 1024 * 1024 * 1024))

# Flakes are not enabled by default in every NixOS installer ISO.
export NIX_CONFIG="${NIX_CONFIG:+${NIX_CONFIG}$'\n'}experimental-features = nix-command flakes"

if [[ -t 1 ]]; then
  C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
  C_PINK=$'\033[38;5;211m'; C_BLUE=$'\033[38;5;111m'
  C_GREEN=$'\033[38;5;114m'; C_YELLOW=$'\033[38;5;221m'; C_RED=$'\033[38;5;203m'
else
  C_RESET=''; C_BOLD=''; C_DIM=''; C_PINK=''; C_BLUE=''; C_GREEN=''; C_YELLOW=''; C_RED=''
fi

say() { printf '%b\n' "$*"; }
info() { say "${C_BLUE}›${C_RESET} $*"; }
ok() { say "${C_GREEN}✓${C_RESET} $*"; }
warn() { say "${C_YELLOW}!${C_RESET} $*"; }
fail() { say "${C_RED}✗${C_RESET} $*" >&2; }

header() {
  clear 2>/dev/null || true
  say "${C_PINK}${C_BOLD}  K O T E Y K A   N I X O S${C_RESET}"
  say "${C_DIM}  Niri desktop · Quickshell · NVIDIA · NixOS 26.05${C_RESET}"
  say "${C_DIM}  ───────────────────────────────────────────────────${C_RESET}"
  say ""
}

usage() {
  cat <<'HELP'
KOTeyka NixOS installer

Usage:
  sudo ./install.sh          Open the interactive installer menu
  sudo ./install.sh --check  Run non-destructive Flake and hardware checks
  sudo ./install.sh --dry-run
                             List disks; do not partition or format anything
  sudo ./install.sh --help   Show this help

The installer performs a fresh UEFI installation to one selected whole disk.
The selected disk is erased only after multiple checks and an exact confirmation.
It is not a dual-boot installer.
HELP
}

require_root() {
  if [[ "$EUID" -ne 0 ]]; then
    fail "Run the installer as root: sudo ./install.sh"
    exit 1
  fi
}

check_uefi() {
  if [[ ! -d /sys/firmware/efi ]]; then
    fail "The installer ISO was not booted in UEFI mode. Reboot the USB in UEFI mode."
    return 1
  fi
  ok "UEFI boot detected"
}

check_commands() {
  local missing=0 command_name
  local -a required=(nix lsblk blockdev swapon nixos-generate-config nixos-install nixos-enter \
    mountpoint tar sed readlink awk grep tee mktemp xargs sort)
  for command_name in "${required[@]}"; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
      fail "Required command is missing: $command_name"
      missing=1
    fi
  done
  [[ "$missing" -eq 0 ]]
}

show_hardware() {
  header
  say "${C_BOLD}Hardware detected by the live ISO${C_RESET}"
  printf '\n'
  if command -v lscpu >/dev/null 2>&1; then
    lscpu | grep -E '^(Architecture|Model name|CPU\(s\)):' || true
  fi
  if command -v free >/dev/null 2>&1; then
    free -h | awk 'NR==2 { printf "RAM: %s total\n", $2 }'
  fi
  if command -v lspci >/dev/null 2>&1; then
    printf '\nGPU / display controllers:\n'
    lspci -nn | grep -Ei 'VGA compatible controller|3D controller|Display controller' || true
  fi
  printf '\nAvailable whole disks:\n'
  lsblk -d -o NAME,SIZE,MODEL,TRAN,RM,RO,TYPE
  printf '\n'
  read -r -p "Press Enter to return to the menu… " _
}

make_work_copy() {
  local destination="$1"
  mkdir -p "$destination"
  tar --exclude='./.git' -cf - -C "$PROJECT_DIR" . | tar -xf - -C "$destination"
}

check_flake() {
  header
  info "Running non-destructive Flake evaluation…"
  if ! command -v nix >/dev/null 2>&1; then
    fail "Nix is unavailable. Boot the official NixOS 26.05 ISO first."
    return 1
  fi

  local check_dir
  check_dir="$(mktemp -d /tmp/koteyka-flake-check.XXXXXX)"
  make_work_copy "$check_dir"

  if ! nix flake lock "$check_dir"; then
    fail "Could not resolve Flake inputs. Check the internet connection and try again."
    return 1
  fi
  if ! nix flake check --no-build "$check_dir"; then
    fail "Flake check failed. No disks were changed. Review the errors above."
    return 1
  fi
  if ! nix build --no-link --dry-run "$check_dir#nixosConfigurations.koteyka.config.system.build.toplevel"; then
    fail "NixOS system evaluation failed. No disks were changed."
    return 1
  fi

  ok "Flake and NixOS toplevel evaluation passed. No disk operation was run."
  rm -rf -- "$check_dir"
}

list_disks() {
  local -a disks=()
  mapfile -t disks < <(lsblk -dpno NAME,TYPE | awk '$2 == "disk" { print $1 }' | sort -V)
  if [[ "${#disks[@]}" -eq 0 ]]; then
    fail "No whole disks were detected."
    return 1
  fi

  say "${C_BOLD}Detected whole disks${C_RESET}"
  printf '\n'
  local i disk size model transport removable readonly
  for i in "${!disks[@]}"; do
    disk="${disks[$i]}"
    size="$(lsblk -dnro SIZE "$disk" | xargs)"
    model="$(lsblk -dnro MODEL "$disk" | xargs)"
    transport="$(lsblk -dnro TRAN "$disk" | xargs)"
    removable="$(lsblk -dnro RM "$disk" | xargs)"
    readonly="$(blockdev --getro "$disk" 2>/dev/null || printf '1')"
    printf '  %s) %-18s %-8s %-26s transport=%-5s removable=%s read-only=%s\n' \
      "$((i + 1))" "$disk" "$size" "${model:-Unknown model}" "${transport:-?}" "${removable:-?}" "$readonly"
  done
  printf '\n'
  DISK_CHOICES=("${disks[@]}")
}

stable_disk_path() {
  local disk="$1" real_path candidate
  real_path="$(readlink -f -- "$disk")"
  shopt -s nullglob
  for candidate in /dev/disk/by-id/*; do
    [[ -L "$candidate" ]] || continue
    [[ "$candidate" == *-part* ]] && continue
    if [[ "$(readlink -f -- "$candidate")" == "$real_path" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "$real_path"
}

check_disk_safety() {
  local disk="$1" size_bytes removable transport read_only_flag mountpoints disk_real swap_device node

  [[ "$(lsblk -dnro TYPE "$disk" | xargs)" == "disk" ]] || {
    fail "Selected path is not a whole disk: $disk"; return 1;
  }

  read_only_flag="$(blockdev --getro "$disk")"
  [[ "$read_only_flag" == "0" ]] || {
    fail "The selected disk is read-only. Refusing to continue."; return 1;
  }

  removable="$(lsblk -dnro RM "$disk" | xargs)"
  transport="$(lsblk -dnro TRAN "$disk" | xargs)"
  if [[ "$removable" == "1" || "$transport" == "usb" ]]; then
    fail "The selected disk looks removable or USB-connected. This may be the installer media. Refusing to erase it."
    return 1
  fi

  mountpoints="$(lsblk -nrpo MOUNTPOINTS "$disk" | sed '/^[[:space:]]*$/d' || true)"
  if [[ -n "$mountpoints" ]]; then
    fail "The selected disk has mounted filesystems. Refusing to continue."
    printf '%s\n' "$mountpoints" >&2
    return 1
  fi

  disk_real="$(readlink -f -- "$disk")"
  while IFS= read -r swap_device; do
    [[ -n "$swap_device" ]] || continue
    while IFS= read -r node; do
      if [[ "$(readlink -f -- "$node" 2>/dev/null || printf '%s' "$node")" == "$disk_real" ]]; then
        fail "The selected disk backs active swap ($swap_device). Disable swap before installation."
        return 1
      fi
    done < <(lsblk -s -nrpo NAME "$swap_device" 2>/dev/null || true)
  done < <(swapon --noheadings --raw --output NAME 2>/dev/null || true)

  size_bytes="$(blockdev --getsize64 "$disk")"
  if (( size_bytes < MIN_DISK_BYTES )); then
    fail "The selected disk is smaller than 80 GiB. Refusing to continue."
    return 1
  fi

  return 0
}

prepare_config_and_preflight() {
  local disk_id="$1" work_dir="$2" work_config="$3" hardware_root template
  template="$work_config/templates/disko.nix.in"
  if [[ ! -s "$template" ]]; then
    fail "Missing Disko layout template: $template"
    return 1
  fi

  sed "s|__DISK_DEVICE__|$disk_id|g" "$template" > "$work_config/hosts/desktop/disko-local.nix"
  if grep -q 'REPLACE-ME\|__DISK_DEVICE__' "$work_config/hosts/desktop/disko-local.nix"; then
    fail "Disko configuration still contains a placeholder. Refusing to continue."
    return 1
  fi

  info "Detecting hardware before touching the selected disk…"
  hardware_root="$work_dir/hardware-root"
  mkdir -p "$hardware_root"
  nixos-generate-config --root "$hardware_root" --no-filesystems
  if [[ ! -s "$hardware_root/etc/nixos/hardware-configuration.nix" ]]; then
    fail "Could not generate hardware-configuration.nix. No disks were changed."
    return 1
  fi
  cp "$hardware_root/etc/nixos/hardware-configuration.nix" \
    "$work_config/hosts/desktop/hardware-configuration.nix"
  if grep -Eq 'fileSystems\.|swapDevices' "$work_config/hosts/desktop/hardware-configuration.nix"; then
    fail "Generated hardware config unexpectedly contains filesystem or swap declarations. Disko owns the disk layout."
    return 1
  fi

  info "Resolving and locking Flake inputs…"
  nix flake lock "$work_config"

  info "Evaluating the full NixOS system derivation without building it…"
  nix flake check --no-build "$work_config"
  nix build --no-link --dry-run \
    "$work_config#nixosConfigurations.koteyka.config.system.build.toplevel"

  info "Validating the selected Disko layout (dry run; no formatting)…"
  nix run "$work_config#disko" -- --mode destroy,format,mount \
    --flake "$work_config#koteyka" --dry-run

  ok "Hardware config, NixOS evaluation and Disko dry-run passed."
}

install_system() {
  require_root
  check_commands || return 1
  check_uefi || return 1

  if [[ -d "$TARGET_ROOT" ]] && mountpoint -q "$TARGET_ROOT"; then
    fail "$TARGET_ROOT is already mounted. This installer expects a clean live ISO session."
    return 1
  fi

  list_disks || return 1
  local selection disk disk_id confirmation work_dir work_config reboot_answer original_disk_real
  read -r -p "Choose target disk number: " selection
  if [[ ! "$selection" =~ ^[0-9]+$ ]] || (( selection < 1 || selection > ${#DISK_CHOICES[@]} )); then
    fail "Invalid disk selection."
    return 1
  fi
  disk="${DISK_CHOICES[$((selection - 1))]}"

  check_disk_safety "$disk" || return 1
  disk_id="$(stable_disk_path "$disk")"
  original_disk_real="$(readlink -f -- "$disk")"
  if [[ ! "$disk_id" =~ ^/dev/[A-Za-z0-9._/+_:-]+$ ]]; then
    fail "Unexpected stable disk identifier: $disk_id"
    return 1
  fi

  work_dir="$(mktemp -d /tmp/koteyka-nixos.XXXXXX)"
  work_config="$work_dir/config"
  make_work_copy "$work_config"

  mkdir -p "$(dirname "$LOG_FILE")"
  : > "$LOG_FILE"
  exec > >(tee -a "$LOG_FILE") 2>&1

  header
  info "Selected disk: $disk_id"
  lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS,MODEL "$disk"
  printf '\n'

  # All expensive validation and hardware detection occurs before the destructive confirmation.
  if ! prepare_config_and_preflight "$disk_id" "$work_dir" "$work_config"; then
    fail "Pre-install checks failed. The selected disk has not been modified."
    warn "Diagnostic log: $LOG_FILE"
    return 1
  fi

  # Re-check immediately before the destructive operation to catch changed mounts/swaps.
  if ! check_disk_safety "$disk"; then
    fail "Disk safety check no longer passes. No disk changes were made."
    return 1
  fi

  header
  say "${C_RED}${C_BOLD}FINAL CHECK — THIS WILL ERASE THE ENTIRE DISK${C_RESET}"
  printf '\n  Device:       %s\n  Stable path:  %s\n  Size:         %s\n' \
    "$disk" "$disk_id" "$(lsblk -dnro SIZE "$disk" | xargs)"
  printf '\n'
  lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS,MODEL "$disk"
  printf '\n'
  warn "Every partition and all data on this disk will be permanently destroyed."
  warn "This installer does not preserve Arch Linux, Windows, or dual-boot partitions."
  read -r -p "To continue, type exactly: ERASE $disk : " confirmation
  if [[ "$confirmation" != "ERASE $disk" ]]; then
    warn "Confirmation did not match. No disk changes were made."
    return 1
  fi

  # Verify that the stable identifier still points to the exact same device,
  # then repeat all safety checks after the user confirmation.
  if [[ ! -b "$disk_id" ]] || [[ "$(readlink -f -- "$disk_id")" != "$original_disk_real" ]]; then
    fail "The selected device identity changed after confirmation. Refusing to format."
    return 1
  fi
  if ! check_disk_safety "$disk_id"; then
    fail "The final disk safety check failed. No disk changes were made."
    return 1
  fi

  info "Running Disko now. The selected disk will be partitioned and formatted."
  nix run "$work_config#disko" -- --mode destroy,format,mount --flake "$work_config#koteyka"

  if ! mountpoint -q "$TARGET_ROOT"; then
    fail "Disko finished but $TARGET_ROOT is not mounted. Stop and inspect $LOG_FILE."
    return 1
  fi

  mkdir -p "$TARGET_CONFIG"
  tar --exclude='./.git' -cf - -C "$work_config" . | tar -xf - -C "$TARGET_CONFIG"

  info "Installing NixOS from the already-evaluated configuration…"
  nixos-install --flake "$TARGET_CONFIG#koteyka" --root "$TARGET_ROOT"

  info "Setting the kostya account password…"
  nixos-enter --root "$TARGET_ROOT" --command "passwd kostya"

  printf '\n'
  ok "KOTeyka NixOS installation completed."
  say "The root password was set during nixos-install; kostya's password was just set."
  warn "Remove the installation USB before rebooting."
  say "Configuration and installation log: $TARGET_CONFIG and $LOG_FILE"

  rm -rf -- "$work_dir"
  read -r -p "Reboot now? [y/N] " reboot_answer
  if [[ "$reboot_answer" =~ ^[Yy]$ ]]; then
    reboot
  else
    say "Reboot later with: reboot"
  fi
}

main() {
  local mode="${1:-menu}"
  case "$mode" in
    --help|-h)
      usage
      ;;
    --check)
      require_root
      check_commands && check_uefi && show_hardware && check_flake
      ;;
    --dry-run)
      require_root
      check_commands && check_uefi || return 1
      list_disks
      warn "Dry run only: no partitioning, formatting or filesystems were changed."
      ;;
    menu)
      require_root
      while true; do
        header
        say "${C_BOLD}Welcome to your Niri desktop installer${C_RESET}"
        say ""
        say "  ${C_PINK}1${C_RESET}  Install KOTeyka NixOS"
        say "  ${C_BLUE}2${C_RESET}  Hardware overview"
        say "  ${C_BLUE}3${C_RESET}  Run non-destructive checks"
        say "  ${C_DIM}4  Exit${C_RESET}"
        printf '\n'
        read -r -p "Choose an option: " choice
        case "$choice" in
          1) install_system || { printf '\n'; read -r -p "Press Enter to return to the menu… " _; } ;;
          2) show_hardware ;;
          3) check_flake || { printf '\n'; read -r -p "Press Enter to return to the menu… " _; } ;;
          4) exit 0 ;;
          *) warn "Choose 1, 2, 3 or 4."; sleep 1 ;;
        esac
      done
      ;;
    *)
      usage
      exit 2
      ;;
  esac
}

main "$@"
