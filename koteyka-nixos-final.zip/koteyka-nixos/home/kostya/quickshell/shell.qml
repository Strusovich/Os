import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ShellRoot {
    id: root

    property bool settingsOpen: false
    property int settingsPage: 0
    property string homeDir: Quickshell.env("HOME") || "/home/kostya"
    property string clockText: Qt.formatDateTime(new Date(), "ddd · dd MMM · hh:mm")
    property string wallpaperPath: homeDir + "/.local/share/kot-os/wallpapers/default.png"
    property string mode: {
        try {
            return JSON.parse(themeFile.text()).mode === "light" ? "light" : "dark";
        } catch (error) {
            return "dark";
        }
    }
    property color accent: {
        try {
            return JSON.parse(themeFile.text()).accent || "#F1A0C8";
        } catch (error) {
            return "#F1A0C8";
        }
    }
    property var palette: mode === "light" ? ({
        panel: "#F2F4F8",
        panelBorder: "#D9DFEA",
        card: "#E6EAF2",
        cardHover: "#DCE2ED",
        field: "#FFFFFF",
        text: "#202638",
        muted: "#657087",
        border: "#CBD3E1",
        accentText: "#202638",
        dock: "#EDF0F6"
    }) : ({
        panel: "#F01B2232",
        panelBorder: "#46516B",
        card: "#2A3144",
        cardHover: "#39435B",
        field: "#252C3E",
        text: "#F0F2F8",
        muted: "#9BA5BD",
        border: "#414C64",
        accentText: "#202333",
        dock: "#E91B2232"
    })

    FileView {
        id: themeFile
        path: root.homeDir + "/.local/state/kot-os/theme.json"
        blockLoading: true
        watchChanges: true
        atomicWrites: true
        onFileChanged: reload()
    }

    Timer {
        interval: 15000
        repeat: true
        running: true
        onTriggered: root.clockText = Qt.formatDateTime(new Date(), "ddd · dd MMM · hh:mm")
    }

    function launch(command) {
        Quickshell.execDetached(command);
    }

    function localBin(name) {
        return root.homeDir + "/.local/bin/" + name;
    }

    function saveTheme(nextMode, nextAccent) {
        themeFile.setText(JSON.stringify({ accent: nextAccent, mode: nextMode }, null, 2));
    }

    function setAccent(value) {
        saveTheme(mode, value);
    }



    PanelWindow {
        id: topBar
        anchors { top: true; left: true; right: true }
        margins { top: 8; left: 12; right: 12 }
        implicitHeight: 54
        exclusiveZone: 62
        color: "transparent"

        Rectangle {
            anchors.fill: parent
            radius: 18
            color: root.palette.dock
            border.width: 1
            border.color: root.palette.panelBorder
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 18
            anchors.rightMargin: 14
            spacing: 14

            Rectangle {
                Layout.preferredWidth: 34
                Layout.preferredHeight: 34
                radius: 12
                color: root.accent
                Text {
                    anchors.centerIn: parent
                    text: "✦"
                    color: root.palette.accentText
                    font.pixelSize: 20
                    font.bold: true
                }
            }

            Column {
                spacing: 0
                Text {
                    text: "KOT OS"
                    color: root.palette.text
                    font.family: "Inter"
                    font.pixelSize: 13
                    font.bold: true
                }
                Text {
                    text: "NIRI EDITION"
                    color: root.palette.muted
                    font.family: "Inter"
                    font.pixelSize: 9
                    font.letterSpacing: 1.5
                }
            }

            Item { Layout.fillWidth: true }

            Text {
                text: "●  WAYLAND"
                color: "#54B68A"
                font.family: "Inter"
                font.pixelSize: 10
                font.bold: true
            }

            Text {
                text: root.clockText
                color: root.palette.text
                font.family: "Inter"
                font.pixelSize: 12
            }

            Button {
                text: "☷  Control Center"
                onClicked: root.settingsOpen = !root.settingsOpen
                implicitHeight: 36
                contentItem: Text {
                    text: parent.text
                    color: root.palette.text
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    radius: 12
                    color: parent.down ? root.palette.cardHover : root.palette.card
                    border.width: 1
                    border.color: root.accent
                }
            }
        }
    }

    PanelWindow {
        id: dock
        anchors { bottom: true; left: true; right: true }
        margins { bottom: 12 }
        implicitHeight: 68
        exclusiveZone: 0
        color: "transparent"

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.verticalCenter: parent.verticalCenter
            width: dockRow.implicitWidth + 24
            height: 58
            radius: 20
            color: root.palette.dock
            border.width: 1
            border.color: root.palette.panelBorder
        }

        RowLayout {
            id: dockRow
            anchors.centerIn: parent
            spacing: 6

            Repeater {
                model: [
                    { label: "Applications", glyph: "⌕", cmd: ["fuzzel"] },
                    { label: "Files", glyph: "▰", cmd: ["kitty", "-e", "yazi"] },
                    { label: "Terminal", glyph: ">_", cmd: ["kitty"] },
                    { label: "System monitor", glyph: "◫", cmd: ["kitty", "-e", "btop"] },
                    { label: "Audio", glyph: "♫", cmd: ["pavucontrol"] }
                ]
                delegate: Button {
                    required property var modelData
                    text: modelData.glyph
                    onClicked: root.launch(modelData.cmd)
                    implicitWidth: 48
                    implicitHeight: 44
                    ToolTip.visible: hovered
                    ToolTip.text: modelData.label
                    contentItem: Text {
                        text: parent.text
                        color: parent.hovered ? root.accent : root.palette.text
                        font.family: "JetBrainsMono Nerd Font"
                        font.pixelSize: 20
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    background: Rectangle {
                        radius: 14
                        color: parent.hovered ? root.palette.cardHover : "transparent"
                    }
                }
            }
        }
    }

    PanelWindow {
        id: controlCenter
        visible: root.settingsOpen
        anchors { top: true; right: true }
        margins { top: 70; right: 14 }
        implicitWidth: 520
        implicitHeight: 620
        focusable: true
        exclusiveZone: 0
        color: "transparent"

        Rectangle {
            anchors.fill: parent
            radius: 24
            color: root.palette.panel
            border.width: 1
            border.color: root.palette.panelBorder
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 13

            RowLayout {
                Layout.fillWidth: true
                ColumnLayout {
                    spacing: 2
                    Text {
                        text: "Control Center"
                        color: root.palette.text
                        font.family: "Inter"
                        font.pixelSize: 22
                        font.bold: true
                    }
                    Text {
                        text: "A little control over your corner of the internet."
                        color: root.palette.muted
                        font.family: "Inter"
                        font.pixelSize: 10
                    }
                }
                Item { Layout.fillWidth: true }
                Button {
                    text: "✕"
                    onClicked: root.settingsOpen = false
                    implicitWidth: 38
                    implicitHeight: 38
                    contentItem: Text {
                        text: parent.text
                        color: root.palette.text
                        font.pixelSize: 16
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    background: Rectangle { radius: 12; color: root.palette.card }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 6
                Repeater {
                    model: ["Overview", "Appearance", "System"]
                    delegate: Button {
                        required property string modelData
                        required property int index
                        text: modelData
                        Layout.fillWidth: true
                        implicitHeight: 38
                        onClicked: root.settingsPage = index
                        contentItem: Text {
                            text: parent.text
                            color: root.settingsPage === index ? root.palette.accentText : root.palette.muted
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.bold: root.settingsPage === index
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                        background: Rectangle {
                            radius: 11
                            color: root.settingsPage === index ? root.accent : root.palette.card
                            border.width: root.settingsPage === index ? 0 : 1
                            border.color: root.palette.border
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.palette.border
            }

            StackLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                currentIndex: root.settingsPage

                // OVERVIEW
                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        spacing: 13

                        RowLayout {
                            Layout.fillWidth: true
                            Text {
                                text: "Quick access"
                                color: root.palette.text
                                font.family: "Inter"
                                font.pixelSize: 15
                                font.bold: true
                            }
                            Item { Layout.fillWidth: true }
                            Text {
                                text: "KOT / DESKTOP"
                                color: root.accent
                                font.family: "Inter"
                                font.pixelSize: 9
                                font.bold: true
                            }
                        }

                        GridLayout {
                            Layout.fillWidth: true
                            columns: 2
                            rowSpacing: 9
                            columnSpacing: 9
                            Repeater {
                                model: [
                                    { label: "Wi-Fi & Networks", glyph: "⌁", command: ["nm-connection-editor"] },
                                    { label: "Bluetooth", glyph: "ᛒ", command: ["blueman-manager"] },
                                    { label: "Sound settings", glyph: "♫", command: ["pavucontrol"] },
                                    { label: "System monitor", glyph: "◫", command: ["kitty", "-e", "btop"] },
                                    { label: "File manager", glyph: "▰", command: ["kitty", "-e", "yazi"] },
                                    { label: "Applications", glyph: "⌕", command: ["fuzzel"] }
                                ]
                                delegate: Button {
                                    required property var modelData
                                    Layout.fillWidth: true
                                    implicitHeight: 46
                                    onClicked: root.launch(modelData.command)
                                    contentItem: RowLayout {
                                        spacing: 9
                                        Text {
                                            text: modelData.glyph
                                            color: root.accent
                                            font.family: "Inter"
                                            font.pixelSize: 16
                                        }
                                        Text {
                                            text: modelData.label
                                            color: root.palette.text
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: Font.DemiBold
                                            Layout.fillWidth: true
                                            elide: Text.ElideRight
                                        }
                                    }
                                    background: Rectangle {
                                        radius: 13
                                        color: parent.down || parent.hovered ? root.palette.cardHover : root.palette.card
                                        border.width: 1
                                        border.color: root.palette.border
                                    }
                                }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            radius: 16
                            color: root.palette.card
                            border.width: 1
                            border.color: root.palette.border
                            implicitHeight: 112

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 15
                                spacing: 6
                                Text {
                                    text: "YOUR SETUP"
                                    color: root.accent
                                    font.family: "Inter"
                                    font.pixelSize: 9
                                    font.bold: true
                                    font.letterSpacing: 1.4
                                }
                                Text {
                                    text: "Intel Core i5-12400F  ·  GeForce RTX 3050"
                                    color: root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    font.bold: true
                                }
                                Text {
                                    text: "32 GB RAM  ·  Niri  ·  Wayland  ·  PipeWire"
                                    color: root.palette.muted
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                }
                                Text {
                                    text: "The hardware details are the project target, not live sensor readings."
                                    color: root.palette.muted
                                    font.family: "Inter"
                                    font.pixelSize: 9
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                        }

                        Item { Layout.fillHeight: true }
                        Text {
                            text: "Tip: Super + D opens the app launcher."
                            color: root.palette.muted
                            font.family: "Inter"
                            font.pixelSize: 10
                        }
                    }
                }

                // APPEARANCE
                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        spacing: 13

                        Text {
                            text: "Make it yours"
                            color: root.palette.text
                            font.family: "Inter"
                            font.pixelSize: 15
                            font.bold: true
                        }
                        Text {
                            text: "Choose a light or dark surface and an accent color. Changes are saved immediately."
                            color: root.palette.muted
                            font.family: "Inter"
                            font.pixelSize: 10
                            wrapMode: Text.WordWrap
                            Layout.fillWidth: true
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 8
                            Button {
                                text: "☾   Dark"
                                Layout.fillWidth: true
                                implicitHeight: 40
                                onClicked: root.saveTheme("dark", root.accent.toString())
                                contentItem: Text {
                                    text: parent.text
                                    color: root.mode === "dark" ? root.palette.accentText : root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    font.bold: true
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                                background: Rectangle {
                                    radius: 11
                                    color: root.mode === "dark" ? root.accent : root.palette.card
                                    border.width: 1
                                    border.color: root.palette.border
                                }
                            }
                            Button {
                                text: "☀   Light"
                                Layout.fillWidth: true
                                implicitHeight: 40
                                onClicked: root.saveTheme("light", root.accent.toString())
                                contentItem: Text {
                                    text: parent.text
                                    color: root.mode === "light" ? root.palette.accentText : root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    font.bold: true
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                                background: Rectangle {
                                    radius: 11
                                    color: root.mode === "light" ? root.accent : root.palette.card
                                    border.width: 1
                                    border.color: root.palette.border
                                }
                            }
                        }

                        Text {
                            text: "ACCENT COLOR"
                            color: root.accent
                            font.family: "Inter"
                            font.pixelSize: 9
                            font.bold: true
                            font.letterSpacing: 1.6
                        }

                        GridLayout {
                            Layout.fillWidth: true
                            columns: 6
                            rowSpacing: 10
                            columnSpacing: 10
                            Repeater {
                                model: ["#F1A0C8", "#93B7FF", "#C4A2FF", "#8DD8BA", "#F4C27D", "#F28E82"]
                                delegate: Rectangle {
                                    required property string modelData
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: 38
                                    radius: 12
                                    color: modelData
                                    border.width: root.accent.toString().toLowerCase() === modelData.toLowerCase() ? 3 : 1
                                    border.color: root.palette.text
                                    MouseArea {
                                        anchors.fill: parent
                                        onClicked: root.setAccent(parent.modelData)
                                    }
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Text {
                                text: "Wallpaper"
                                color: root.palette.text
                                font.family: "Inter"
                                font.pixelSize: 12
                                font.bold: true
                            }
                            Item { Layout.fillWidth: true }
                            Button {
                                text: "Sample current ↗"
                                implicitHeight: 34
                                onClicked: root.launch([root.localBin("kot-theme-from-wallpaper")])
                                contentItem: Text {
                                    text: parent.text
                                    color: root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                                background: Rectangle {
                                    radius: 10
                                    color: root.palette.card
                                    border.width: 1
                                    border.color: root.palette.border
                                }
                            }
                        }

                        TextField {
                            id: wallpaperField
                            Layout.fillWidth: true
                            placeholderText: "Absolute path to an image…"
                            color: root.palette.text
                            placeholderTextColor: root.palette.muted
                            font.family: "Inter"
                            font.pixelSize: 11
                            background: Rectangle {
                                radius: 11
                                color: root.palette.field
                                border.color: root.palette.border
                                border.width: 1
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            Button {
                                text: "Apply wallpaper"
                                Layout.fillWidth: true
                                implicitHeight: 38
                                enabled: wallpaperField.text.trim().length > 0
                                onClicked: root.launch([root.localBin("kot-wallpaper"), wallpaperField.text.trim()])
                                contentItem: Text {
                                    text: parent.text
                                    color: root.palette.accentText
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                    font.bold: true
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                                background: Rectangle { radius: 10; color: root.accent }
                            }
                            Button {
                                text: "Reset"
                                implicitHeight: 38
                                onClicked: root.launch([root.localBin("kot-wallpaper")])
                                contentItem: Text {
                                    text: parent.text
                                    color: root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                                background: Rectangle {
                                    radius: 10
                                    color: root.palette.card
                                    border.width: 1
                                    border.color: root.palette.border
                                }
                            }
                        }
                        Item { Layout.fillHeight: true }
                    }
                }

                // SYSTEM
                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        spacing: 13

                        Text {
                            text: "System tools"
                            color: root.palette.text
                            font.family: "Inter"
                            font.pixelSize: 15
                            font.bold: true
                        }
                        Text {
                            text: "Small utilities for everyday desktop maintenance."
                            color: root.palette.muted
                            font.family: "Inter"
                            font.pixelSize: 10
                        }

                        Repeater {
                            model: [
                                { label: "Lock screen", glyph: "⌑", command: ["swaylock"] },
                                { label: "Take screenshot", glyph: "▧", command: [root.localBin("kot-screenshot")] },
                                { label: "Open terminal", glyph: ">_", command: ["kitty"] },
                                { label: "Bluetooth devices", glyph: "ᛒ", command: ["blueman-manager"] }
                            ]
                            delegate: Button {
                                required property var modelData
                                Layout.fillWidth: true
                                implicitHeight: 46
                                onClicked: root.launch(modelData.command)
                                contentItem: RowLayout {
                                    spacing: 10
                                    Text {
                                        text: modelData.glyph
                                        color: root.accent
                                        font.family: "Inter"
                                        font.pixelSize: 16
                                    }
                                    Text {
                                        text: modelData.label
                                        color: root.palette.text
                                        font.family: "Inter"
                                        font.pixelSize: 11
                                        font.weight: Font.DemiBold
                                        Layout.fillWidth: true
                                    }
                                    Text {
                                        text: "↗"
                                        color: root.palette.muted
                                        font.pixelSize: 12
                                    }
                                }
                                background: Rectangle {
                                    radius: 13
                                    color: parent.down || parent.hovered ? root.palette.cardHover : root.palette.card
                                    border.width: 1
                                    border.color: root.palette.border
                                }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            radius: 15
                            color: root.palette.card
                            border.width: 1
                            border.color: root.palette.border
                            implicitHeight: 100
                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 5
                                Text {
                                    text: "KOT OS · NIRI"
                                    color: root.accent
                                    font.family: "Inter"
                                    font.pixelSize: 9
                                    font.bold: true
                                    font.letterSpacing: 1.3
                                }
                                Text {
                                    text: "NixOS 26.05 · Home Manager · Quickshell"
                                    color: root.palette.text
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                }
                                Text {
                                    text: "Use `sudo nixos-rebuild switch --flake /etc/nixos#koteyka` after editing the configuration."
                                    color: root.palette.muted
                                    font.family: "Inter"
                                    font.pixelSize: 9
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                        }
                        Item { Layout.fillHeight: true }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.palette.border
            }

            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "KOT OS / PERSONAL DESKTOP"
                    color: root.palette.muted
                    font.family: "Inter"
                    font.pixelSize: 9
                    font.bold: true
                }
                Item { Layout.fillWidth: true }
                Text {
                    text: "✦"
                    color: root.accent
                    font.pixelSize: 13
                }
            }
        }
    }
}
