{ config, lib, pkgs, ... }:
{
  imports = [ ./programs.nix ];

  home.username = "kostya";
  home.homeDirectory = "/home/kostya";
  home.stateVersion = "26.05";

  home.packages = with pkgs; [
    yazi
    btop
    playerctl
    pavucontrol
    networkmanagerapplet
    blueman
    libnotify
    wl-clipboard
    brightnessctl
    eza
    xwayland-satellite
  ];

  programs.kitty = {
    enable = true;
    settings = {
      font_family = "JetBrainsMono Nerd Font";
      font_size = 11;
      background = "#171b29";
      foreground = "#edf0f7";
      cursor = "#f1a0c8";
      selection_background = "#39445d";
      background_opacity = "0.96";
      window_padding_width = 14;
      confirm_os_window_close = 0;
      enable_audio_bell = false;
    };
  };

  programs.fuzzel = {
    enable = true;
    settings = {
      main = {
        terminal = "kitty";
        layer = "overlay";
        width = 48;
        font = "JetBrainsMono Nerd Font:size=11";
        prompt = "    ";
        lines = 10;
      };
      colors = {
        background = "171b29f2";
        text = "edf0f7ff";
        prompt = "f1a0c8ff";
        placeholder = "9099b0ff";
        input = "edf0f7ff";
        match = "f1a0c8ff";
        selection = "30384cff";
        "selection-text" = "edf0f7ff";
        "selection-match" = "f1a0c8ff";
        border = "f1a0c8ff";
      };
      border = {
        width = 2;
        radius = 18;
      };
    };
  };

  programs.fish = {
    enable = true;
    interactiveShellInit = ''
      set -g fish_greeting
      set -gx EDITOR vim
      set -gx VISUAL vim
      alias ll 'eza -lah --icons=auto'
      alias rebuild 'sudo nixos-rebuild switch --flake /etc/nixos#koteyka'
      alias update 'cd /etc/nixos; and nix flake update; and sudo nixos-rebuild switch --flake /etc/nixos#koteyka'
    '';
  };

  programs.starship.enable = true;
  programs.git.enable = true;
  programs.yazi.enable = true;
  programs.bat.enable = true;
  programs.fzf.enable = true;

  services.mako = {
    enable = true;
    settings = {
      font = "Inter 10";
      background-color = "#202638";
      text-color = "#edf0f7";
      border-color = "#f1a0c8";
      border-radius = 14;
      border-size = 2;
      default-timeout = 5000;
      width = 360;
      padding = 14;
      margin = 12;
    };
  };

  xdg.configFile."niri/config.kdl".source = pkgs.runCommand "koteyka-niri-config" {
    nativeBuildInputs = [ pkgs.niri ];
  } ''
    niri validate --config ${./niri/config.kdl}
    cp ${./niri/config.kdl} "$out"
  '';
  xdg.configFile."quickshell/kot-os/shell.qml".source = ./quickshell/shell.qml;
  xdg.configFile."quickshell/kot-os/README.txt".text = ''
    KOT Shell is a custom Quickshell interface for Niri.
    Source: /etc/nixos/home/kostya/quickshell/shell.qml
  '';

  home.file.".local/share/kot-os/wallpapers/default.png".source = ../../assets/wallpapers/default.png;
  home.file.".local/bin/kot-wallpaper" = {
    source = ../../scripts/kot-wallpaper;
    executable = true;
  };
  home.file.".local/bin/kot-theme-from-wallpaper" = {
    source = ../../scripts/kot-theme-from-wallpaper;
    executable = true;
  };
  home.file.".local/bin/kot-screenshot" = {
    source = ../../scripts/kot-screenshot;
    executable = true;
  };

  home.activation.kotThemeState = lib.hm.dag.entryAfter [ "writeBoundary" ] ''
    $DRY_RUN_CMD mkdir -p "$HOME/.local/state/kot-os"
    if [ ! -e "$HOME/.local/state/kot-os/theme.json" ]; then
      $DRY_RUN_CMD cp ${./theme.json} "$HOME/.local/state/kot-os/theme.json"
    fi
  '';

  home.sessionPath = [ "$HOME/.local/bin" ];
  home.sessionVariables = {
    EDITOR = "vim";
    BROWSER = "firefox";
    NIXOS_OZONE_WL = "1";
  };

  programs.home-manager.enable = true;
}
