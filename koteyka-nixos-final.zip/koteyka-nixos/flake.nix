{
  description = "KOTeyka NixOS — Niri desktop with a custom adaptive Quickshell interface";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";

    home-manager = {
      url = "github:nix-community/home-manager/release-26.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    disko = {
      url = "github:nix-community/disko";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = inputs@{ nixpkgs, home-manager, disko, ... }:
    let
      pkgs = nixpkgs.legacyPackages.x86_64-linux;
    in {
    packages.x86_64-linux.disko = disko.packages.x86_64-linux.disko;
    checks.x86_64-linux.niri-config = pkgs.runCommand "koteyka-niri-config-validation" {
      nativeBuildInputs = [ pkgs.niri ];
    } ''
      niri validate --config ${./home/kostya/niri/config.kdl}
      mkdir -p "$out"
      cp ${./home/kostya/niri/config.kdl} "$out/config.kdl"
    '';

    nixosConfigurations.koteyka = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = { inherit inputs; };
      modules = [
        disko.nixosModules.disko
        home-manager.nixosModules.home-manager
        ./hosts/desktop
        {
          home-manager = {
            useGlobalPkgs = true;
            useUserPackages = true;
            backupFileExtension = "backup";
            users.kostya = import ./home/kostya;
          };
        }
      ];
    };
  };
}
