# KOTeyka NixOS

A personalized NixOS desktop for the user's Intel Core i5-12400F, NVIDIA RTX 3050 8 GB and 32 GB RAM PC. The desktop is built around **Niri + a custom Quickshell interface** — not GNOME, KDE, Noctalia or a pre-made desktop shell.

The goal is a fresh, playful, adaptive desktop with the convenience of a polished rice: top bar, bottom dock, a custom Control Center, light/dark mode, accent colors, wallpaper sampling, app launchers and keyboard-first window management.

## What is included

- NixOS 26.05 stable Flake, Home Manager and Disko.
- Niri Wayland compositor, SDDM login manager and NVIDIA configuration for the RTX 3050.
- KOT Shell built with Quickshell: Overview, Appearance and System pages.
- Persistent light/dark mode and accent color; sample an accent from the current wallpaper.
- Wallpaper manager with transitions, screenshot helper, app launcher, terminal, Yazi and btop.
- PipeWire audio, NetworkManager, Bluetooth, polkit, portals and common desktop utilities.
- Interactive installation menu with disk inspection, generated hardware config, NixOS/Disko preflight evaluation and exact destructive confirmation.

## Publish to GitHub once

The source archive is prepared, but it is not published to a GitHub account automatically. Create an empty repository named `koteyka-nixos` and follow [docs/PUBLISH.md](docs/PUBLISH.md) once. After that, each installation uses the simple `git clone` + `sudo ./install.sh` flow below.

## Install from the official NixOS ISO

> **Warning:** this is a fresh-install workflow. It erases the entire selected disk. It does not preserve Arch Linux, Windows, existing files or dual-boot partitions. Back up everything important to a different physical drive before proceeding.

1. Create a bootable **NixOS 26.05 x86_64 ISO** USB and boot it in UEFI mode.
2. Connect to the internet.
3. Open a terminal and clone your GitHub repository (replace `GITHUB_USER` with the account that owns the repository):

   ```bash
   git clone https://github.com/GITHUB_USER/koteyka-nixos.git
   cd koteyka-nixos
   ```

4. Start the installer (it automatically requests administrator privileges):

   ```bash
   ./install.sh
   ```

5. Choose **1 — Install KOTeyka NixOS**.
6. Select the target whole disk, for example `/dev/nvme0n1` — never select a partition such as `/dev/nvme0n1p1`.
7. The installer generates the machine-specific hardware configuration and checks the Flake, NixOS toplevel evaluation and Disko layout before it asks for the final confirmation.
8. Inspect the device list again. To authorize formatting, type the exact phrase displayed by the installer: `ERASE /dev/<disk>`.
9. The installer partitions the selected disk, installs NixOS, asks you to set the root password and then sets the `kostya` account password.
10. Remove the USB and reboot. Select the Niri session in SDDM if it is not selected automatically.

The installation creates a GPT disk with a 1 GiB EFI system partition and one ext4 root filesystem. It uses zram for compressed swap and does not create a swap partition. The installed configuration is stored at `/etc/nixos`.

## Installer options

```bash
sudo ./install.sh --check     # Flake and NixOS evaluation; no disk changes
sudo ./install.sh --dry-run   # list detected disks; no disk changes
sudo ./install.sh --help
./tests/static-check.sh       # local source-level checks
```

The installer rejects removable/USB disks, read-only disks, mounted disks, active swap, and disks smaller than 80 GiB. This is an extra guard, not a substitute for reading the selected device carefully. The final confirmation remains destructive.

## Desktop controls

### Main shortcuts

| Shortcut | Action |
|---|---|
| `Super + Return` | Open Kitty terminal |
| `Super + D` | Open Fuzzel app launcher |
| `Super + H/J/K/L` | Focus left/down/up/right |
| `Super + Ctrl + H/J/K/L` | Move column/window |
| `Super + Shift + H/J/K/L` | Focus another monitor |
| `Super + Ctrl + Shift + H/J/K/L` | Move column to another monitor |
| `Super + 1..5` | Switch workspace |
| `Super + Shift + 1..5` | Move column to workspace |
| `Super + F` | Maximize column |
| `Super + Shift + F` | Fullscreen |
| `Super + V` | Toggle floating |
| `Super + Alt + L` | Lock screen |
| `Print` | Screenshot selection |
| Audio keys | Change volume / mute |
| Media keys | Play/pause, next, previous |

### KOT Control Center

Open **Control Center** in the top bar. It has three pages:

- **Overview:** shortcuts for network, Bluetooth, audio, file manager, applications and system monitor.
- **Appearance:** light/dark mode, accent palette, wallpaper path, default wallpaper reset and sampling an accent from the current wallpaper.
- **System:** lock screen, screenshot, terminal and Bluetooth tools, plus rebuild information.

The shell is a custom starting interface, not a claim of exact feature parity with AngelOS. Most device-specific settings open the appropriate system utility rather than pretending to implement hardware controls internally.

### Wallpaper

```bash
kot-wallpaper /absolute/path/to/image.png
kot-wallpaper                         # restore bundled wallpaper
kot-theme-from-wallpaper              # resample accent from selected wallpaper
```

The accent and appearance mode are stored in `~/.local/state/kot-os/theme.json`. Sampling a new wallpaper keeps the chosen light/dark mode.

## Rebuild and update

After changing configuration files:

```bash
sudo nixos-rebuild switch --flake /etc/nixos#koteyka
```

Update the locked dependencies and rebuild:

```bash
cd /etc/nixos
nix flake update
sudo nixos-rebuild switch --flake .#koteyka
```

The installer creates `flake.lock` before formatting the disk and copies it into `/etc/nixos`. Commit that lock file to GitHub after the first successful installation if you want future installs from the repository to use exactly the same dependency revisions.

## Repository structure

```text
flake.nix
hosts/desktop/          Host modules, Disko layout, generated hardware config
modules/nixos/          Base system, Niri and NVIDIA modules
home/kostya/            Home Manager, Niri and Quickshell configuration
scripts/                Wallpaper, adaptive theme and screenshot helpers
assets/wallpapers/      Bundled starter wallpaper
templates/              Disko template filled in by the installer
tests/                  Static validation scripts
.github/workflows/      CI checks
docs/                   Install notes and self-audit
```

## Important limitations

- The installer is for a fresh **UEFI full-disk** installation only. It is not a dual-boot setup and intentionally does not attempt to preserve existing partitions.
- The layout is unencrypted ext4. There is no LUKS setup or disk swap partition.
- NVIDIA + Wayland + Niri behavior depends on the exact driver, kernel, monitor and connection. This project targets the RTX 3050, but actual boot and display behavior must be confirmed on the PC.
- No NixOS build, Quickshell runtime launch, Niri config validation or physical disk test can be certified from a source-only archive. The CI workflow performs Nix evaluation; the installer repeats preflight evaluation in the live ISO.
- If installation fails after Disko has begun, the selected disk may already be repartitioned. Do not reboot blindly: inspect `/tmp/koteyka-nixos-install.log`, `lsblk -f` and `mount | grep /mnt` first.

## License

MIT for project-authored configuration and scripts. Third-party packages retain their own licenses.
