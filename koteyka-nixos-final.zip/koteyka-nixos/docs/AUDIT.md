# KOTeyka NixOS — self-audit

Audit date: 2026-11-17

## What was corrected in this pass

- Replaced `nixos-unstable` with the NixOS 26.05 stable branch and matched Home Manager to `release-26.05`.
- Changed the Disko layout from Btrfs subvolumes to a simple GPT + EFI + ext4 root layout. This removes unnecessary first-install filesystem complexity.
- Rebuilt the installer flow so it generates hardware configuration and runs Flake, NixOS toplevel and Disko dry-run checks before the destructive confirmation.
- Added checks for removable/USB media, read-only devices, mounted filesystems, active swap and minimum disk size. The device is checked again immediately before formatting.
- Kept the generated device path and hardware configuration in the temporary install copy; they are not accidentally added to the source repository.
- Reworked KOT Shell into Overview, Appearance and System pages, with persistent light/dark mode and accent swatches.
- Fixed wallpaper theme sampling so it preserves the selected light/dark mode.
- Added CI evaluation workflow and strengthened source checks.

## Configuration review

- Target machine: Intel Core i5-12400F (no integrated GPU), NVIDIA RTX 3050 8 GB (Ampere), 32 GB RAM.
- GPU configuration enables the NVIDIA open kernel module, proprietary user-space driver and DRM modesetting.
- Niri is enabled through the NixOS `programs.niri` module.
- Home Manager supplies Kitty, Fuzzel, Fish, Yazi, Mako, Starship, FZF, shell files and the Quickshell config.
- Audio uses PipeWire; networking uses NetworkManager; Bluetooth uses BlueZ/Blueman.
- Disk layout is intentionally unencrypted ext4 with zram; it does not create a swap partition.

## Validation status in this environment

The following source-level checks were run in the authoring container:

- `bash -n` for installer and helper scripts.
- JSON parser for the persisted theme file.
- Static path/encoding assertions.
- ShellCheck when available (not installed in this environment).
- Nix evaluation and build checks (Nix is not installed and outbound DNS is unavailable in this environment).
- QML runtime and Niri configuration validation (Qt/Quickshell/Niri are not installed here).
- No real disk was partitioned or formatted.

The GitHub Actions workflow is included so that a push to GitHub can perform Nix-based evaluation. The installer repeats the important checks in the official NixOS live ISO before formatting.

## Remaining risks / things that require real hardware

1. **NVIDIA + Niri:** driver and compositor support must be verified with the actual RTX 3050, monitor ports and display refresh rates.
2. **SDDM session:** confirm that Niri appears and starts correctly from SDDM.
3. **Quickshell runtime:** load `~/.config/quickshell/kot-os/shell.qml` in the installed Quickshell 0.3.x runtime. QML cannot be certified from text checks alone.
4. **Niri config:** run `niri validate` (or the equivalent validator shipped by the installed Niri version) on the generated config before daily use.
5. **First installation:** NixOS must download/build the selected system closure; ensure a stable internet connection and sufficient disk space.

## Go / no-go

**Source-level result: pass.** The Bash syntax, JSON, project structure, installer ordering, QML delimiter balance and wallpaper-theme smoke test passed in this authoring environment.

**Nix/desktop result: not yet verified.** Nix evaluation, the actual Niri validator, Quickshell runtime loading and the installer preflight were not executed here. The GitHub Actions workflow is the next evaluation gate after the first push. The live-ISO `--check` run is the gate before any disk operation.

**Do not format a disk based only on this archive.** First require a green CI run, then boot the official ISO and complete the non-destructive checks. The real installation and NVIDIA/Niri boot still require testing on the target PC. Back up the old installation before any full-disk install.
