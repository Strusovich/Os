# Installation notes

## Expected environment

- Official NixOS 26.05 x86_64 installer ISO.
- Booted in UEFI mode.
- Working internet connection.
- One internal whole disk of at least 80 GiB available for a fresh install.
- A full backup of everything on the target disk.

## Installer flow

1. Check root privileges, required NixOS tools and UEFI mode.
2. List whole disks and show model, size, transport, removable and read-only flags.
3. Reject USB/removable devices, read-only devices, mounted filesystems, active swap and disks smaller than 80 GiB.
4. Resolve a stable `/dev/disk/by-id/` path where possible.
5. Copy the project to a temporary working directory.
6. Generate a machine-specific `hardware-configuration.nix` from the live ISO before any disk operation; use `--no-filesystems` because Disko owns the layout.
7. Write the selected device into `hosts/desktop/disko-local.nix` in the temporary copy.
8. Lock Flake inputs, run `nix flake check --no-build`, evaluate the NixOS toplevel derivation with `nix build --dry-run`, and ask Disko to resolve its script with `--dry-run`.
9. Re-check the disk and show its full block-device tree.
10. Require the exact phrase `ERASE <selected-device>`.
11. Re-resolve the stable device identifier and repeat the safety checks after confirmation.
12. Run Disko to create GPT + 1 GiB EFI + ext4 root, then mount it at `/mnt`.
13. Copy the locked project and generated hardware configuration to `/mnt/etc/nixos`.
14. Run `nixos-install`, set the normal user's password using `nixos-enter`, and offer reboot.

## Safety notes

- The installer never has a preservation/dual-boot mode.
- The removable/USB check is deliberately conservative. If it rejects a disk, do not work around it by editing the script; investigate which disk is actually the internal target.
- A successful `--dry-run` is not a partitioning test. It only confirms that the Disko script can be evaluated.
- `nix build --dry-run` evaluates the system derivation graph but does not compile/download the entire system closure.
- Once Disko's destructive command starts, the target disk may already be erased even if a later step fails.

## Recovery

If installation stops after partitioning, keep the machine in the live ISO. Read `/tmp/koteyka-nixos-install.log`, inspect `lsblk -f`, inspect mounted filesystems with `findmnt`, and only then decide whether to rerun or repair the install.
