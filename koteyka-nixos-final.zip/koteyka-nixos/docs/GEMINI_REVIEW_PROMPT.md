# External review prompt

You are reviewing a NixOS 26.05 desktop project. Do not assume any claim in the README is correct; inspect the source.

Target PC: Intel Core i5-12400F (no iGPU), NVIDIA RTX 3050 8 GB (Ampere), 32 GB RAM, UEFI. Desktop: Niri + custom Quickshell shell. Home Manager is integrated as a NixOS module. Disko installs GPT + 1 GiB EFI + ext4 root. The installer must not destroy disks until all non-destructive checks have passed and the user types the exact confirmation phrase.

Review these areas:

1. Nix expression syntax, NixOS option validity for nixpkgs 26.05, Home Manager `release-26.05` option validity, and all package attribute names.
2. Flake inputs and Disko integration. Check that the Flake can evaluate and that generated hardware configuration does not conflict with Disko filesystems.
3. NVIDIA open-kernel-module settings for RTX 3050, DRM modesetting, SDDM, Wayland and Niri.
4. Niri KDL syntax and whether every configured action exists in the targeted Niri version.
5. Quickshell QML syntax and runtime APIs, especially `ShellRoot`, `PanelWindow`, `FileView`, `execDetached`, QtQuick Controls and the custom Control Center.
6. Installer Bash behavior and destructive-operation safety. Pay special attention to live-USB detection, mounted filesystems, active swap, read-only disks, the selected stable device path, preflight evaluation, the Disko dry-run, and confirmation order.
7. Wallpaper and screenshot scripts, PATH assumptions, Pillow package inclusion, and persistent theme JSON behavior.
8. Documentation consistency and failure recovery instructions.

Rules:
- Do not run the installer or any disk-writing command.
- Do not weaken safety checks to make tests pass.
- Do not replace Niri or Quickshell with a different desktop.
- Do not silently change the target filesystem or NixOS release.
- If an option or API cannot be verified, mark it uncertain rather than inventing certainty.
- Fix concrete defects directly in the files and explain each changed file.
- Run `tests/static-check.sh`, `shellcheck` if available, `nix flake check --no-build`, and NixOS toplevel evaluation/build checks where the environment permits.
- At the end, provide a list of checks that passed, checks that could not be run, and all remaining hardware-specific risks.
