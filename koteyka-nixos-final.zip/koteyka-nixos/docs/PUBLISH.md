# Publish KOTeyka NixOS to GitHub once

The project archive is ready, but it is not automatically attached to a GitHub account. Create an **empty** repository named `koteyka-nixos` on GitHub (do not pre-create a README, license or `.gitignore`).

From the extracted project directory, run:

```bash
git init -b main
git add .
git commit -m "Initial KOTeyka NixOS setup"
git remote add origin https://github.com/GITHUB_USER/koteyka-nixos.git
git push -u origin main
```

Replace `GITHUB_USER` with the GitHub account that owns the empty repository. GitHub will ask you to authenticate through your configured Git credential manager or browser flow. Never put a password or token directly in the remote URL.

After the first push, installation on the NixOS live ISO is:

```bash
git clone https://github.com/GITHUB_USER/koteyka-nixos.git
cd koteyka-nixos
sudo ./install.sh
```

The installer creates a local `flake.lock` in its temporary working copy before formatting and copies that lock file into `/etc/nixos`. After a successful installation, you may copy `/etc/nixos/flake.lock` back into your Git checkout and commit it to pin the exact input revisions for future installations.
