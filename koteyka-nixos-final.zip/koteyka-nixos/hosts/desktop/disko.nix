# Safe placeholder. install.sh writes the selected disk to the ignored
# disko-local.nix file before evaluating or running Disko.
{ ... }:
{
  disko.devices.disk.main = {
    device = "/dev/disk/by-id/REPLACE-ME-WITH-INSTALLER";
    type = "disk";
    content = {
      type = "gpt";
      partitions = {
        ESP = {
          size = "1G";
          type = "EF00";
          content = {
            type = "filesystem";
            format = "vfat";
            mountpoint = "/boot";
            mountOptions = [ "umask=0077" ];
          };
        };
        root = {
          size = "100%";
          content = {
            type = "filesystem";
            format = "ext4";
            mountpoint = "/";
            mountOptions = [ "noatime" ];
          };
        };
      };
    };
  };
}
