{ lib, ... }:
{
  imports = [
    (if builtins.pathExists ./disko-local.nix then ./disko-local.nix else ./disko.nix)
    ../../modules/nixos/base.nix
    ../../modules/nixos/niri.nix
    ../../modules/nixos/nvidia.nix
  ] ++ lib.optional (builtins.pathExists ./hardware-configuration.nix) ./hardware-configuration.nix;
}
